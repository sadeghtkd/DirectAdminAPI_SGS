# DirectAdmin API for Python
This package help you manage DirectAdmin control panel via API.
## Sample usage
```    
    api = PrettyAPI(username=admin_da_user,password=admin_da_pwd,server=da_url,json=True)
    #Get list of users that has access to a protected folder in DirectAdmin
    da_users = api.get_protected_directory_users('/domains/test.com/public_html/manager')
  
    users = da_users['users']
    for key in users:
        print(users[key])
```